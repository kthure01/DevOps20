'''
Den har while-loopen printar ut "Hej" i all oandlighet.
Din uppgift ar att gora sa den bara printar ut "Hej" 3 ganger.

OBS: Du far inte ta bort loopen
'''
while True:
    print("Hej")
