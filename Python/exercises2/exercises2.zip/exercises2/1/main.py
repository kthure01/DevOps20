# Denna funktion ska oppna "input.txt" och returnera innehallet.
def get_contents_from_file():
    return ""


contents = get_contents_from_file("input.txt")
print(contents)

'''
Det korrekta svaret som printas ut ska vara:

    Jag kan Python!
'''
