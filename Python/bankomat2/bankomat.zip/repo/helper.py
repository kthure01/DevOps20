def clear():
    import os
    os.system('export TERM=xterm; clear')
